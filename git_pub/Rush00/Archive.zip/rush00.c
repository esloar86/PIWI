/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eslopez- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/08 11:30:09 by eslopez-          #+#    #+#             */
/*   Updated: 2023/07/08 12:28:36 by eslopez-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char a);

void	rush(int x, int y)
{
	int	posicion_h;
	int	posicion_v;

//
/* Inicializamos posicion_v a 1. Será utilizado para recorrer todos los puntos desde 1 hasta 'y' */
//
	posicion_v = 1;
	while ((posicion_v <= y) && (x > 0))
	{
//
/* Inicializamos posicion_h a 1. Será utilizado para recorrer todos los puntos desde 1 hasta 'h' */
//
		posicion_h = 1;
		while (posicion_h <= x)
		{
//
/* Si se cumple que simultáneamente la posicion_h no es 1 (la primera esquina) y tampoco es x (la última esquina), y además, se cumple que posicion_y tampoco es ninguna de las esquinas de abajo, pinta linea horizontal (este bucle pinta el 'techo' y el 'suelo' del cuadrado*/
//
			if ((posicion_h != 1 && posicion_h != x) && (posicion_v == 1 || posicion_v == y))
				ft_putchar('-');
//
/* Si se cumple que simultáneamente la posicion_h es 1 o 'x'(es decir, que sea el principio o final de la linea), y además, se cumple que posicion_y no es la primera linea horizontal o la última, pinta linea vertical (este bucle pinta las paredes laterales */
//
			else if ((posicion_h == 1 || posicion_h == x) && (posicion_v != 1 && posicion_v != y))
				ft_putchar('|');
//
/* Si el punto que estamos evaluando es la primera esquina, o la segunda esquina (horizontal), o la primera esquina 'de abajo', o la segunda esquina 'de abajo'. Entonces, pintará el circulito (las esquinas del cuadrado) */
//
			else if ((posicion_h == 1) || (posicion_h == x) || (posicion_v == 1) || (posicion_v == y))
				ft_putchar('o');
//
/* Si no cumple ninguna de las condiciones anteriores, entonces es que la posición evaluada está 'dentro' del cuadrado, y por tanto hay que pintar un vacío */
//
			else
				ft_putchar(' ');
//
/* Aumenta el punto a evaluar horizontal, es decir, se evalúa el siguiente punto hacia la derecha, hasta que llegue a 'x' */
//
			posicion_h++;
		}
// Para que entienda que no lo tiene que pintar todo de corrido, introducimos un salto de linea para 'linea' horizontal evaluada
		ft_putchar('\n');
//
/* Aumenta el punto a evaluar vertical, es decir, se evalúa el siguiente punto hacia abajo, hasta que llegue a 'y' */
//
		posicion_v++;
	}
}
